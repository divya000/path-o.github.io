<?php get_header(); ?>
<div class="content404">
  <div class="window">
    <div class="toolbar">
    <div class="top">
      <div class="lights">
        <div class="light red">
          <div class="glyph">&nbsp;</div>
          <div class="shine"></div>
          <div class="glow"></div>
        </div>
        <div class="light yellow">
          <div class="glyph">&nbsp;</div>
          <div class="shine"></div>
          <div class="glow"></div>
        </div>
        <div class="light green">
          <div class="glyph">&nbsp;</div>
          <div class="shine"></div>
          <div class="glow"></div>
        </div>
      </div>
      <div class="title">
		    National Day of Civic Hacking
      </div>
    </div>
    </div>
    <div class="consolebody">
      Last login: Tue May 6 10:06:02 on console <br />
      National-day-of-Civic-Hacking:~ 404 Page Not Found <br/>
      --- </br>
      ### TYPE 'HOME' TO VISIT THE HOMEPAGE OR TYPE 'BACK' TO RETURN 
      TO THE PREVIOUS PAGE. OR, Y'KNOW, TYPE SOMETHING ELSE. ###<br/>
    </div>
  </div>
  <div class="navigation"><a href="<?php bloginfo('url'); ?>">Homepage</a> / <a href="javascript:history.back();">Previous Page</a> / <a href="<?php echo get_bloginfo('url').'/contact'; ?>">Report a problem?</a></div>
</div>
<?php get_footer(); ?>